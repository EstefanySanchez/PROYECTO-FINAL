﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace LoginRegister
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            INITIALIZER();
        }

        private void Sesion()
        {
            string connect= "datasource=localhost;port=3306;username=root;password=;database=hospitalfagi";
            string query = "select * from doctorlogin where User = '" + userTxtBox.Text + "' AND PASSWORD = '" + pswTxtBox.Text + "'";
            MySqlConnection databaseConnection = new MySqlConnection(connect);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;

            try
            {
                databaseConnection.Open();
                reader = commandDatabase.ExecuteReader();
                if (reader.Read())
                {
                    MessageBox.Show("Bienvenido al Hospital");
                }
                else
                {
                    MessageBox.Show("Usuario/Contraseña incorrectos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void userTxtBox_TextChanged(object sender, EventArgs e)
        { 

        }
        private void INITIALIZER()
        {
            pswTxtBox.Text = "";
            pswTxtBox.PasswordChar = '*';
            pswTxtBox.MaxLength = 255;
        }
        private void pswTxtBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            Sesion();
        }

        private void registerbtn_Click(object sender, EventArgs e)
        {
            Form2 registrar = new Form2();
            registrar.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 bitacora = new Form3();
            bitacora.Show();
        }
    }
}
