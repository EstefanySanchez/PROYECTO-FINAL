-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-11-2020 a las 20:11:15
-- Versión del servidor: 10.4.14-MariaDB
-- Versión de PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hospitalfagi`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dibaddress`
--

CREATE TABLE `dibaddress` (
  `ID_Address_Dib` int(10) NOT NULL,
  `Calle` varchar(255) CHARACTER SET ascii NOT NULL,
  `Colonia` varchar(255) CHARACTER SET ascii NOT NULL,
  `Municipio` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diblogin`
--

CREATE TABLE `diblogin` (
  `ID_DIB` int(10) NOT NULL,
  `User` varchar(255) CHARACTER SET ascii NOT NULL,
  `Password` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `diblogin`
--

INSERT INTO `diblogin` (`ID_DIB`, `User`, `Password`) VALUES
(1, 'Estefany De los Santos ', 'Estef16..07'),
(3, 'Giselle Vargas', 'Giss..2134');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dibname`
--

CREATE TABLE `dibname` (
  `ID_Nombre_Dib` int(10) NOT NULL,
  `Nombre(s)` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_paterno` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_materno` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dibregister`
--

CREATE TABLE `dibregister` (
  `ID_DIB` int(10) NOT NULL,
  `ID_Nombre_Dib` int(10) NOT NULL,
  `ID_Sexo` int(10) NOT NULL,
  `Edad` int(10) NOT NULL,
  `Telefono` varchar(12) CHARACTER SET ascii NOT NULL,
  `ID_Estudio` int(10) NOT NULL,
  `Cedula_profesional` int(8) NOT NULL,
  `ID_Address_Dib` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctoraddress`
--

CREATE TABLE `doctoraddress` (
  `ID_Address_Doctor` int(10) NOT NULL,
  `Calle` varchar(255) CHARACTER SET ascii NOT NULL,
  `Colonia` varchar(255) CHARACTER SET ascii NOT NULL,
  `Municipio` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctoregister`
--

CREATE TABLE `doctoregister` (
  `ID_Medicos` int(10) NOT NULL,
  `ID_Nombre_Medico` int(10) NOT NULL,
  `ID_Sexo` int(10) NOT NULL,
  `Edad` int(10) NOT NULL,
  `Telefono` varchar(12) CHARACTER SET ascii NOT NULL,
  `Cedula_profesional` int(8) NOT NULL,
  `ID_Address_Doctor` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctorlogin`
--

CREATE TABLE `doctorlogin` (
  `ID_Medicos` int(10) NOT NULL,
  `User` varchar(255) CHARACTER SET ascii NOT NULL,
  `Password` varchar(255) CHARACTER SET ascii NOT NULL,
  `Nombre` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_Paterno` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_materno` varchar(255) CHARACTER SET ascii NOT NULL,
  `Calle` varchar(255) CHARACTER SET ascii NOT NULL,
  `Colonia` varchar(255) CHARACTER SET ascii NOT NULL,
  `Municipio` varchar(255) CHARACTER SET ascii NOT NULL,
  `Estado` varchar(255) CHARACTER SET ascii NOT NULL,
  `Edad` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `doctorlogin`
--

INSERT INTO `doctorlogin` (`ID_Medicos`, `User`, `Password`, `Nombre`, `Apellido_Paterno`, `Apellido_materno`, `Calle`, `Colonia`, `Municipio`, `Estado`, `Edad`) VALUES
(7, 'Meredith', '9e0d2d27c08051c0a962c1a3a8c03c74f5554043', 'Meredith', 'Grey', 'Seattle', '30 de Junio', 'La piedad', 'Cuautitlan Izcalli', 'Seattle', '42'),
(8, 'Fanny', 'edd960a0e1fd9d61228a545038ee3b91c7e373d6', 'Estefany', 'de los Santos', 'Mexico', 'Nopaltepec', 'Lindavista', 'Izcalli', 'Campeche', '32'),
(9, 'Oscar', 'bb0687d2dc7c3d46b026f76980c3a24dc9d21a20', 'Oscar', 'Guzman', 'Hernandez', '30 de Junio', 'bellavista', 'Tultitlan', 'Veracruz', '45'),
(10, 'Dino', 'd35dbc1062811528deb6f94f1aa671cf1f093b6a', 'Dinorah', 'Montes', 'Diaz', '15 de septiembre', 'tepalcapa', 'Cuautitlan Izcalli', '26', 'Chiapas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctorname`
--

CREATE TABLE `doctorname` (
  `ID_Nombre_Medico` int(10) NOT NULL,
  `Nombre(s)` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_paterno` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_materno` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `doctorname`
--

INSERT INTO `doctorname` (`ID_Nombre_Medico`, `Nombre(s)`, `Apellido_paterno`, `Apellido_materno`) VALUES
(1, 'Sofia', 'Perez', 'Diaz');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `escolaridad`
--

CREATE TABLE `escolaridad` (
  `ID_Estudio` int(10) NOT NULL,
  `Escolaridad` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidades`
--

CREATE TABLE `especialidades` (
  `ID_especialidad` int(10) NOT NULL,
  `Especialidad` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Volcado de datos para la tabla `especialidades`
--

INSERT INTO `especialidades` (`ID_especialidad`, `Especialidad`) VALUES
(1, 'Cardiologia'),
(2, 'Neurologia'),
(3, 'Ginecologia'),
(4, 'Urgencias'),
(5, 'Oftalmologia'),
(6, 'Jefatura IBM');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad_dib`
--

CREATE TABLE `especialidad_dib` (
  `ID_especialidad` int(10) NOT NULL,
  `ID_DIB` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad_doc`
--

CREATE TABLE `especialidad_doc` (
  `ID_especialidad` int(10) NOT NULL,
  `ID_Medicos` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `especialidad_doc`
--

INSERT INTO `especialidad_doc` (`ID_especialidad`, `ID_Medicos`) VALUES
(1, 1),
(2, 4),
(3, 2),
(4, 3),
(5, 5),
(6, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `especialidad_pac`
--

CREATE TABLE `especialidad_pac` (
  `ID_especialidad` int(10) NOT NULL,
  `ID_Pacientes` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `patientaddress`
--

CREATE TABLE `patientaddress` (
  `ID_Address_Paciente` int(10) NOT NULL,
  `Calle` varchar(255) CHARACTER SET ascii NOT NULL,
  `Colonia` varchar(255) CHARACTER SET ascii NOT NULL,
  `Municipio` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `patientname`
--

CREATE TABLE `patientname` (
  `ID_Nombre_Paciente` int(10) NOT NULL,
  `Nombre(s)` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_paterno` varchar(255) CHARACTER SET ascii NOT NULL,
  `Apellido_materno` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `patientregister`
--

CREATE TABLE `patientregister` (
  `ID_Paciente` int(10) NOT NULL,
  `ID_Nombre_Paciente` int(10) NOT NULL,
  `ID_Sexo` int(10) NOT NULL,
  `Edad` int(10) DEFAULT NULL,
  `Telefono` varchar(12) NOT NULL,
  `RFC` varchar(255) CHARACTER SET armscii8 NOT NULL,
  `ID_Address_Paciente` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sexo`
--

CREATE TABLE `sexo` (
  `ID_Sexo` int(10) NOT NULL,
  `Sexo` varchar(255) CHARACTER SET ascii NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `sexo`
--

INSERT INTO `sexo` (`ID_Sexo`, `Sexo`) VALUES
(1001, 'Femenino'),
(1002, 'Masculino');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `dibaddress`
--
ALTER TABLE `dibaddress`
  ADD PRIMARY KEY (`ID_Address_Dib`);

--
-- Indices de la tabla `diblogin`
--
ALTER TABLE `diblogin`
  ADD PRIMARY KEY (`ID_DIB`);

--
-- Indices de la tabla `dibname`
--
ALTER TABLE `dibname`
  ADD PRIMARY KEY (`ID_Nombre_Dib`);

--
-- Indices de la tabla `dibregister`
--
ALTER TABLE `dibregister`
  ADD PRIMARY KEY (`ID_DIB`);

--
-- Indices de la tabla `doctoraddress`
--
ALTER TABLE `doctoraddress`
  ADD PRIMARY KEY (`ID_Address_Doctor`);

--
-- Indices de la tabla `doctoregister`
--
ALTER TABLE `doctoregister`
  ADD PRIMARY KEY (`ID_Medicos`);

--
-- Indices de la tabla `doctorlogin`
--
ALTER TABLE `doctorlogin`
  ADD PRIMARY KEY (`ID_Medicos`);

--
-- Indices de la tabla `doctorname`
--
ALTER TABLE `doctorname`
  ADD PRIMARY KEY (`ID_Nombre_Medico`);

--
-- Indices de la tabla `escolaridad`
--
ALTER TABLE `escolaridad`
  ADD PRIMARY KEY (`ID_Estudio`);

--
-- Indices de la tabla `especialidades`
--
ALTER TABLE `especialidades`
  ADD PRIMARY KEY (`ID_especialidad`);

--
-- Indices de la tabla `especialidad_dib`
--
ALTER TABLE `especialidad_dib`
  ADD PRIMARY KEY (`ID_especialidad`);

--
-- Indices de la tabla `especialidad_doc`
--
ALTER TABLE `especialidad_doc`
  ADD PRIMARY KEY (`ID_especialidad`);

--
-- Indices de la tabla `especialidad_pac`
--
ALTER TABLE `especialidad_pac`
  ADD PRIMARY KEY (`ID_especialidad`);

--
-- Indices de la tabla `patientaddress`
--
ALTER TABLE `patientaddress`
  ADD PRIMARY KEY (`ID_Address_Paciente`);

--
-- Indices de la tabla `patientname`
--
ALTER TABLE `patientname`
  ADD PRIMARY KEY (`ID_Nombre_Paciente`);

--
-- Indices de la tabla `patientregister`
--
ALTER TABLE `patientregister`
  ADD PRIMARY KEY (`ID_Paciente`);

--
-- Indices de la tabla `sexo`
--
ALTER TABLE `sexo`
  ADD PRIMARY KEY (`ID_Sexo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `dibaddress`
--
ALTER TABLE `dibaddress`
  MODIFY `ID_Address_Dib` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `diblogin`
--
ALTER TABLE `diblogin`
  MODIFY `ID_DIB` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `dibname`
--
ALTER TABLE `dibname`
  MODIFY `ID_Nombre_Dib` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `dibregister`
--
ALTER TABLE `dibregister`
  MODIFY `ID_DIB` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `doctoraddress`
--
ALTER TABLE `doctoraddress`
  MODIFY `ID_Address_Doctor` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `doctoregister`
--
ALTER TABLE `doctoregister`
  MODIFY `ID_Medicos` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `doctorlogin`
--
ALTER TABLE `doctorlogin`
  MODIFY `ID_Medicos` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `doctorname`
--
ALTER TABLE `doctorname`
  MODIFY `ID_Nombre_Medico` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `escolaridad`
--
ALTER TABLE `escolaridad`
  MODIFY `ID_Estudio` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `especialidades`
--
ALTER TABLE `especialidades`
  MODIFY `ID_especialidad` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `especialidad_dib`
--
ALTER TABLE `especialidad_dib`
  MODIFY `ID_especialidad` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `especialidad_doc`
--
ALTER TABLE `especialidad_doc`
  MODIFY `ID_especialidad` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `especialidad_pac`
--
ALTER TABLE `especialidad_pac`
  MODIFY `ID_especialidad` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `patientaddress`
--
ALTER TABLE `patientaddress`
  MODIFY `ID_Address_Paciente` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `patientname`
--
ALTER TABLE `patientname`
  MODIFY `ID_Nombre_Paciente` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `patientregister`
--
ALTER TABLE `patientregister`
  MODIFY `ID_Paciente` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
